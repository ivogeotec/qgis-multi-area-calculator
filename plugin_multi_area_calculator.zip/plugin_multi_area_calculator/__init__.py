from .multi_area_provider import MultiAreaProvider

def classFactory(iface):
    return MultiAreaProvider()
