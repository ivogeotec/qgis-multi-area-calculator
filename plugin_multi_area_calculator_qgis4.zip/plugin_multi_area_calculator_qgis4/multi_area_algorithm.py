from qgis.PyQt.QtCore import QCoreApplication, QVariant
from qgis.core import (QgsProcessing,
                       QgsFeatureSink,
                       QgsProcessingAlgorithm,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterFeatureSink,
                       QgsProcessingParameterEnum,
                       QgsField)

class MultiAreaAlgorithm(QgsProcessingAlgorithm):
    INPUT = 'INPUT'
    OUTPUT = 'OUTPUT'
    UNITS = 'UNITS'

    UNIT_OPTIONS = [
        'Metros Quadrados / Sq Meters (m²)',
        'Quilômetros Quadrados / Sq Kilometers (km²)',
        'Hectares (ha)',
        'Acres (ac)',
        'Milhas Quadradas / Sq Miles (mi²)',
        'Alqueire Paulista (2.42 ha)',
        'Alqueire Mineiro (4.84 ha)'
    ]

    CONVERSION_FACTORS = [
        1.0,            # m²
        1e-6,           # km²
        1e-4,           # ha
        0.000247105,    # ac
        3.861e-7,       # mi²
        1/24200,        # Alqueire Paulista
        1/48400         # Alqueire Mineiro
    ]

    FIELD_NAMES = ['area_m2', 'area_km2', 'area_ha', 'area_ac', 'area_mi2', 'alq_paul', 'alq_min']

    def tr(self, string):
        return QCoreApplication.translate('Processing', string)

    def createInstance(self):
        return MultiAreaAlgorithm()

    def name(self):
        return 'multiareapro'

    def displayName(self):
        return self.tr('Calculadora de Áreas Múltiplas / Multi-Area Calculator')

    def group(self):
        return ''

    def groupId(self):
        return ''

    # Este método adiciona a descrição no canto direito da janela
    def shortHelpString(self):
        return self.tr("EN | Professional geoprocessing tool for multi-unit area calculation.\n\n"
                       "BR | Ferramenta profissional de geoprocessamento para cálculo de áreas em múltiplas unidades.")

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, self.tr('Camada de Entrada / Input Layer'), [QgsProcessing.TypeVectorPolygon]))

        self.addParameter(QgsProcessingParameterEnum(
            self.UNITS,
            self.tr('Unidades de Saída / Output Units'),
            options=self.UNIT_OPTIONS,
            allowMultiple=True,
            defaultValue=[0, 1, 2]
        ))

        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, self.tr('Camada de Saída / Output Layer')))

    def processAlgorithm(self, parameters, context, feedback):
        source = self.parameterAsSource(parameters, self.INPUT, context)
        selected_indices = self.parameterAsEnums(parameters, self.UNITS, context)
        
        fields = source.fields()
        for i in selected_indices:
            fields.append(QgsField(self.FIELD_NAMES[i], QVariant.Double, len=20, prec=4))

        (sink, dest_id) = self.parameterAsSink(parameters, self.OUTPUT, context,
                                               fields, source.wkbType(), source.sourceCrs())

        features = source.getFeatures()
        for feature in features:
            geom = feature.geometry()
            m2 = geom.area()
            
            new_attrs = feature.attributes()
            for i in selected_indices:
                new_attrs.append(m2 * self.CONVERSION_FACTORS[i])
            
            feature.setAttributes(new_attrs)
            sink.addFeature(feature, QgsFeatureSink.FastInsert)

        return {self.OUTPUT: dest_id}
